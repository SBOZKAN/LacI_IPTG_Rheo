#!/bin/bash

#SBATCH -N 1
#SBATCH -n 2
#SBATCH -p physicsgpu1
#SBATCH -q sozkan_longgpu
#SBATCH --gres=gpu:GTX1080:1
#SBATCH -t 4-0:00
#SBATCH -o slurm.%N.%j.out
#SBATCH -e slurm.%N.%j.err
#cd $PBS_O_WORKDIR

usage="""
Production run on GPU
======================

Description
-----------
Runs production on GPU. Adjust run time, stepsize and output frequency in production.in

IMP NOTE: Run production_cpu.sh first as system initializes better in cpu then GPU

Usage
-----
./production_gpu.sh PARMFIL <>-prod_cpu.rst
"""

module load cuda/9.0.176
module load namd/2.13b1-cuda
module load python/2.7.14
NAMDHOME="/packages/7x/namd/2.13b1/bin"

${NAMDHOME}/charmrun ${NAMDHOME}/namd2 +p2 +idlepoll minimd.namd > gpu.log
